﻿param
(
    [switch]$multibox,
    [Parameter(Mandatory=$false)]
    [string]$relatedFilesDir,
    [Parameter(Mandatory=$false)]
    [string]$targetDirectory,
    [Parameter(Mandatory=$false)]
    [string]$deploymentDir,
	[Parameter(Mandatory=$false)]
    [string]$LogDir,
    [Parameter(Mandatory=$false)]
    [switch] $useStaging
)

$Global:installedPackages=@()

function GenerateSymLinkNgen([string]$webroot,[string]$metadataPackagePath)
{
    $DeveloperBox = Get-DevToolsInstalled
    if(!($DeveloperBox))
    { 
        write-output "Updating Symlink and Ngen Assemblies"
        $SymLinkNgenLog = join-path $LogDir "update_SymLink_NgenAssemblies.log"
        $argumentList = '–webroot:"$webroot" –packagedir:"$metadataPackagePath" –log:"$SymLinkNgenLog"'
			
	    $NgenoutPutLog=join-path $LogDir "update_NgenOutput_$datetime.log"
  
		if(!(Test-Path $NgenoutPutLog)){
			New-Item -ItemType file $NgenoutPutLog -Force
        }

        invoke-Expression "$metadataPackagePath\bin\CreateSymLinkAndNgenAssemblies.ps1 $argumentList" >> $NgenoutPutLog
	}
}

function UpdateAdditionalFiles([string]$webRoot,[string]$packageDir)
{
    $directorys = Get-ChildItem $packageDir -Directory
    foreach ($moduleName in $directorys) 
    {
        $modulePath=Join-Path $packageDir $moduleName
        $additionalFilesDir=join-path $modulePath "AdditionalFiles"

        if(Test-Path $additionalFilesDir)
        {
            Write-log "Processing additional files for '$moduleName' "
            $filelocationsfile=join-path "$modulePath" "FileLocations.xml"
            if(Test-Path "$filelocationsfile")
            {
                [System.Xml.XmlDocument] $xd = new-object System.Xml.XmlDocument
                $xd.Load($filelocationsfile)
                $files=$xd.SelectNodes("//AdditionalFiles/File")
                foreach($file in $files)
                {
                    $assembly=[System.IO.Path]::GetFileName($file.Source)
                    $destination=$file.Destination
                    $relativepath=$file.RelativePath
                    $fullassemblypath=join-path "$modulePath" "AdditionalFiles\$assembly"

                    # the reason why we need to check for IsNullorEmpty() for the parameters is because the c:\pakages\bin
                    # comes from both the platform and app side. If the app bin package gets installed first
                    # it will leave a FileLocations.xml file at c:\packages\bin which will be processed by the 
                    # platform bin package when it gets installed. We want to ensure that we do not throw an exception
                    # even if we don't find the correct set of parameters being passed from the calling function. 
                    switch($destination)
                    {
                        "AOSWeb" #enum for AOS webroot
                        {
                            $target=join-path "$webRoot" "$relativepath"
                        }

                        "PackageBin" #enum for \packages\bin
                        {
                            if(-not [string]::IsNullOrEmpty($packageDir))
                            {   
                                $target=join-path "$packageDir" "bin"
                            }
                        }

                        "ModuleBin" #enum for \<<modulename>>\bin
                        {
                            $target=join-path "$modulePath" "bin"
                        }

		                "PackageDir" #enum for \packages\<<relativepath>>
		                {
                            if(-not [string]::IsNullOrEmpty($packageDir))
                            {
			                    $target=join-path "$packageDir" "$relativepath"
                            }
		                }
                    }

                    if((Test-Path "$fullassemblypath") -and (-not [string]::IsNullOrEmpty($target)))
                    {
                        if(!(Test-Path "$target"))
                        {
                            Write-log "Creating target directory '$target'"
                            New-item -Path "$target" -ItemType "directory" -Force
                        }

                        $targetfile=join-path "$target" $assembly
                        Write-log "Copying '$fullassemblypath' to '$targetfile'"
                        Copy-Item -path:"$fullassemblypath" -destination:"$targetfile" -Force
                    }
                }
            }   

            Write-log "Removing '$additionalFilesDir'..."
            Remove-Item -Path $additionalFilesDir -Recurse -Force|out-null
        } 
    }
}

function Update-PackageReferenceFile([string]$metadataPath,[string]$packageZipPath)
{
    $ErrorActionPreference = "stop"
    $7zip=join-path $env:SystemDrive "DynamicsTools\7za.exe"
    $guid=[System.Guid]::NewGuid()
    $tempdir=[System.IO.Path]::GetTempPath()+$guid
    $temppackagesdir=join-path $tempdir "DynamicsAx-Package-Reference"
   
    if(Test-Path $packageZipPath)
    {
        if(!(Test-Path $temppackagesdir)){
           
            New-Item $temppackagesdir -ItemType directory -Force >$null
        }
    
        $zip = Start-Process $7zip -ArgumentList "x $packageZipPath -o$temppackagesdir -y -mmt" -Wait -WindowStyle Hidden -PassThru
	    if($zip.ExitCode -ne "0")
	    {
		    throw "7Zip failed to extract dynamicss packages reference file."
	    }

        $directorys = Get-ChildItem $temppackagesdir -Directory
        foreach ($directory in $directorys) 
        {
            $TargetReferenceUpdateDirectory = join-path $metadataPath $directory.Name
            if(Test-Path $TargetReferenceUpdateDirectory)
            {
                Copy-Item -Path ([IO.Path]::Combine($directory.FullName,"*")) -Destination $TargetReferenceUpdateDirectory -Force -Recurse
            }
        
        }

        if(Test-Path $temppackagesdir) {
            Remove-Item $temppackagesdir -recurse -force
        } 
    }
}

function Install-Package([string]$packageName,[string]$metadataPath,[string]$source,[string]$log)
{
    $ErrorActionPreference = "stop"

    $dynamicstools="DynamicsTools"
    $installationrecords = Join-Path $metadataPath "InstallationRecords"
    $packageinstallationrecord = Join-Path $installationrecords $packageName
   
    $nuget=join-path $env:SystemDrive "$dynamicstools\nuget.exe"
    
    "removing package installation record $packageinstallationrecord.*" >> $log
    get-childitem -path "$installationrecords" -filter "$packageName.*" | remove-item -force -recurse

    "Unpacking the Dynamics packages to $installationrecords" >> $log

    "Running command: $nuget install -OutputDirectory `"$installationrecords`" $packageName -Source $source" >> $log
    & $nuget install -OutputDirectory "$installationrecords" $packageName -Source $source
    # check the last exit code and decide if the package(s) were installed correctly
    if($LASTEXITCODE -ne 0)
    {
        Throw "Something went wrong when installing the Dynamics package '$packageName'. Make sure the package name is correct and that it exists at the source directory '$source'."
    }
    
} 

function Install-ZipPackage ([string]$clickoncePath,[string]$metadataPath,[string]$frameworkPath,[string]$packageZipPath,[string]$source,[string]$webroot,[string]$log)
{
    $ErrorActionPreference = "stop"

    #install package
    $arguments='clickOnceInstallPath="{0}";metadataInstallPath="{1}";frameworkInstallPath="{2}";packageZipDrop="{3}";webroot="{4}";log="{5}"' -f $clickoncePath,$metadataPath,$frameworkPath,$packageZipPath,$webroot,$log
    $arguments
    $env:DynamicsPackageParameters=$arguments
    $dynamicstools="DynamicsTools"
    $installationrecords = Join-Path $metadataPath "InstallationRecords"
    $packageinstallationrecord = Join-Path $installationrecords $packageName

    # iterate over every installed package and run the custom powershell script
    $packagesdir=[System.IO.Directory]::EnumerateDirectories($installationrecords,"*",[System.IO.SearchOption]::TopDirectoryOnly)
    foreach ($dir in $packagesdir){
        $currentpackagename=[System.IO.Path]::GetFileName($dir)
        $toolsdir=Join-Path $dir "tools"
        $installscript=join-path $toolsdir "installpackage.ps1"
        if(Test-Path $installscript){ 
           $Global:installedPackages+=$currentpackagename

        }     
    }
    Parallel-Install -packagesName:$Global:installedPackages -installationrecorddir:$installationrecords
}


function Remove-MetadataSourceDirectory([string] $packageName, [string] $packageInstallPath)
{
    $basePackageName = $($packageName.split('-')[1])
    
    if ($packageName.EndsWith('-compile'))
    {
        $packageInstallPath = Join-Path $packageInstallPath $basePackageName
        $packageInstallPath = Join-Path $packageInstallPath 'XppMetadata'
        if(Test-Path $packageInstallPath)
        {
            #powershell bug - Remove-Item comlet doesn't implement -Recurse correctly
            #Remove-Item $packageInstallPath -Force -Recurse
            get-childitem -path "$packageInstallPath" -recurse | remove-item -force -recurse
        }
    }
    if ($packageName.EndsWith('-develop'))
    {
        $packageInstallPath = Join-Path $packageInstallPath $basePackageName
        $packageInstallPath = Join-Path $packageInstallPath $basePackageName
        if(Test-Path $packageInstallPath)
        {
            #powershell bug - Remove-Item comlet doesn't implement -Recurse correctly
            #Remove-Item $packageInstallPath -Force -Recurse
            get-childitem -path "$packageInstallPath" -recurse | remove-item -force -recurse
        }
    }
}

workflow Parallel-Install([string[]] $packagesName, [string] $installationrecorddir)
{
    $ErrorActionPreference = "stop"
    foreach -parallel -ThrottleLimit 2 ($pkg in $packagesName){
        $dir = Join-Path $installationrecorddir $pkg
        $toolsdir=Join-Path $dir "tools"
        $installscript=join-path $toolsdir "installpackage.ps1"
        if(Test-Path $installscript){
            Write-Output "Running script '$installScript'"
            InlineScript {& $Using:installscript}
            Move-item $installscript ($installscript+".executed") -Force
        }
        
    }
}

Import-Module WebAdministration
Import-Module "$PSScriptRoot\CommonRollbackUtilities.psm1" -DisableNameChecking
Import-Module "$PSScriptRoot\AosEnvironmentUtilities.psm1" -Force -DisableNameChecking

$ErrorActionPreference = "stop"


if($useStaging)
{
    $webroot = join-path $(Get-AosServiceStagingPath) "webroot"
    $metadataPackagePath = join-path $(Get-AosServiceStagingPath) "PackagesLocalDirectory"
    $frameworkPackagePath = join-path $(Get-AosServiceStagingPath) "PackagesLocalDirectory"
}
else
{
    $webroot = Get-AosWebSitePhysicalPath
    $metadataPackagePath = $(Get-AOSPackageDirectory)
    $frameworkPackagePath = $(Get-AOSPackageDirectory)
    
}

$clickOncePackagePath = $(Get-InfrastructureClickonceAppsDirectory)
$clickOncePackagePath = [IO.Path]::Combine($webroot,$clickOncePackagePath)
$resourcePath = [IO.Path]::Combine($webroot,"Resources")
$sourcePath = [IO.Path]::Combine($(split-Path -parent $PSScriptRoot), "Packages")
$packageZipDrop = [IO.Path]::Combine($sourcePath,"files")


if((![string]::IsNullOrWhiteSpace($targetDirectory)) -and (Test-path $targetDirectory))
{
    $metadataPackagePath = $targetDirectory
    $frameworkPackagePath = $targetDirectory
}   

if((![string]::IsNullOrWhiteSpace($deploymentDir)) -and (Test-path $deploymentDir))
{
    if($multibox)
    {
        $clickOncePackagePath = [IO.Path]::Combine($deploymentDir,"WebRoot\apps")
        $webroot=[IO.Path]::Combine($deploymentDir,"WebRoot")
        $resourcePath = [IO.Path]::Combine($deploymentDir,"WebRoot\Resources")
    }
    else
    {
        $clickOncePackagePath = [IO.Path]::Combine($deploymentDir,"DObind\Packages\Cloud\AosWebApplication\AosWebApplication.csx\roles\AosWeb\approot\apps")
        $webroot=[IO.Path]::Combine($deploymentDir,"DObind\Packages\Cloud\AosWebApplication\AosWebApplication.csx\roles\AosWeb\approot")
        $resourcePath = [IO.Path]::Combine($deploymentDir,"DObind\Packages\Cloud\AosWebApplication\AosWebApplication.csx\roles\AosWeb\approot\Resources")
    }
}

if((![string]::IsNullOrWhiteSpace($relatedFilesDir)) -and (Test-Path $relatedFilesDir))
{
    $sourcePath = $relatedFilesDir
    $packageZipDrop = [IO.Path]::Combine($relatedFilesDir,"files")
}    

$datetime=get-date -Format "MMddyyyyhhmmss"

if(!$LogDir)
{
    $LogDir = $PSScriptRoot
}

$log=join-path $LogDir "install-AXpackages_$datetime.log"
  
if(!(Test-Path $log)){
    New-Item -ItemType file $log -Force
}

$innerlog=join-path $LogDir "update-AXpackages_$datetime.log"
  
if(!(Test-Path $innerlog)){
    New-Item -ItemType file $innerlog -Force
}


$startdatetime=get-date
"*******************************************************" >> $log
"** Starting the package deployment at $startdatetime **" >> $log
"*******************************************************" >> $log

$installationrecords = Join-Path -Path $metadataPackagePath -ChildPath "InstallationRecords"

if(!(Test-Path $installationrecords))
{
        "creating installation record directory '$installationrecords' to kept the installation history" >> $log
        New-Item $installationrecords -ItemType directory -Force
}
else
{               
    # clean up prior nuget installation of the previous package that fail to install
    $packagesdir=[System.IO.Directory]::EnumerateDirectories($installationrecords,"*",[System.IO.SearchOption]::TopDirectoryOnly)
    foreach ($dir in $packagesdir)
    {
        $toolsdir=Join-Path $dir "tools"
        $installscript=join-path $toolsdir "installpackage.ps1"
        if(Test-Path $installscript)
        {
            Move-item $installscript ($installscript+".executed") -Force
        }
    }
}



$DeveloperBox = Get-DevToolsInstalled

#Check if this is a platform update package base on existence of the config file.
#if it's platformUpdate3 or later, also perform the meta package installation for platform binarys
if ((Test-Path "$PSScriptRoot\PlatformUpdatePackages.Config") -or (Get-IsPlatformUpdate3OrLater))
{
    if(Test-Path $sourcePath)
    {
        [Void][Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem')
        if ($DeveloperBox -eq $true)
        {
            $PackageToInstall = "dynamicsax-meta-platform-development"
        }
        else
        {
            $PackageToInstall = "dynamicsax-meta-platform-runtime"
        }
        if(![string]::IsNullOrWhiteSpace($PackageToInstall))
        {
            $zipFile = Get-Item $sourcePath\$PackageToInstall*.nupkg
            if($zipFile -eq $null)
            {
                #only throw error if it's a dedicated inplace upgrade package, 
                #on any other package it's possible that the meta package doesn't existing thus no operation required
                if(Test-Path "$PSScriptRoot\PlatformUpdatePackages.Config")
                {
                    Throw "Unable to get package information"
                }

            }
            else
            {
                $PackFiles = [IO.Compression.ZipFile]::OpenRead($zipFile).Entries
                $PackageSpec =  $PackFiles | where {($_.Name -like '*.nuspec')}

                if(!($PackageSpec))
                {
                    Throw "Unable to get package information"
                }

                [System.Xml.XmlDocument] $xmlDoc=new-object System.Xml.XmlDocument
                $XmlDoc.Load($PackageSpec.Open())

                $Dependencies = $xmlDoc.GetElementsByTagName('dependency').id

                if($Dependencies.Contains("dynamicsax-systemhealth"))
                {
                    #Remove AxPulse due to the name change to SystemHealth in PlatUpdate3
                    $axPulsePath = Join-Path -Path $metadataPackagePath -ChildPath "axpulse"
                   
                    if(Test-Path $axPulsePath)
                    {
                        Remove-Item $axPulsePath -Force -Recurse
                    }
                    if(Test-Path $installationrecords)
                    {
                        get-childitem -path "$installationrecords" -filter "dynamicsax-axpulse.*" | remove-item -force -recurse 
                    }
                }

                #Install all packages in meta-package definition
                forEach ($Package in $Dependencies)
                {
                    #if it's not appFall or later, install directory package from platform
                    #all other platform package specified in meta package will get installed
                    if(($($package.Split("-")[1]) -ne 'Directory') -or (!$(Get-IsAppFallOrLater)))
                    {
                        "removing package installation record $Package.*" >> $log
                        get-childitem -path "$installationrecords" -filter "$Package.*" | remove-item -force -recurse  
                        
                        #Remove MetaData and Source Directories for the package before Installing
                        Remove-MetadataSourceDirectory -packageName $Package -packageInstallPath $metadataPackagePath 
                    }
                }
                Install-Package -packageName:$PackageToInstall -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
            }
        }
    }
}

#Install App packages if it is sealed
if($(Get-IsAppSealed))
{
    if(Test-Path $sourcePath)
    {
        [Void][Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem')   
        $DeveloperBox = Get-DevToolsInstalled
        if ($DeveloperBox -eq $true)
        {
            $PackageToInstall = "dynamicsax-meta-application-development"
        }
        else
        {
            $PackageToInstall = "dynamicsax-meta-application-runtime"
        }
        if(![string]::IsNullOrWhiteSpace($PackageToInstall))
        {
            $zipFile = Get-Item $sourcePath\$PackageToInstall*.nupkg

            if($zipFile -ne $null)
            {
                $PackFiles = [IO.Compression.ZipFile]::OpenRead($zipFile).Entries
                $PackageSpec =  $PackFiles | Where-Object {($_.Name -like "*.nuspec")}

                if(!($PackageSpec))
                {
                    Throw "Unable to get package information"
                }

                [System.Xml.XmlDocument] $xmlDoc=new-object System.Xml.XmlDocument
                $XmlDoc.Load($PackageSpec.Open())

                $Dependencies = $xmlDoc.GetElementsByTagName('dependency').id

                #Install all packages in meta-package definition
                forEach ($Package in $Dependencies)
                {
                    "removing package installation record $Package.*" >> $log
                    get-childitem -path "$installationrecords" -filter "$Package.*" | remove-item -force -recurse

                    #Remove MetaData and Source Directories for the package before Installing
                    Remove-MetadataSourceDirectory -packageName $Package -packageInstallPath $metadataPackagePath
                }
                Install-Package -packageName:$PackageToInstall -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
            }  
        }
    }
}

#still need to perform the aot package installation that's not part of platform or app.
if(!(Test-Path "$PSScriptRoot\PlatformUpdatePackages.Config"))
{
    if(Test-Path $sourcePath)
    {
        $files=get-childitem -Path:$sourcePath *.nupkg
        foreach ($packageFile in $files) 
        {
            #if it's not platupdate3 or later, install all package
            #if it's platupdate3 or later, install all package that's not part of platform
            if($(Get-IsModulePartOfPlatformAsBinary -packageNugetFile $packageFile.FullName))
            {
                if(!$(Get-IsPlatformUpdate3OrLater))
                {
                    Install-Package -packageName:($packageFile.BaseName).Split(".")[0] -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
                }
            }
            # If app is not sealed, install all [Application Package]
            elseif(Get-IsModulePartOfApplicationAsBinary -PackageNugetFilePath $packageFile.FullName)
            {
                if(!$(Get-IsAppSealed))
                {
                    Install-Package -packageName:($packageFile.BaseName).Split(".")[0] -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
                }
            }
            # Allow customer extension
            else
            {
                Install-Package -packageName:($packageFile.BaseName).Split(".")[0] -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
            }
        }
    }
}

Install-ZipPackage -metadataPath:$metadataPackagePath -clickoncePath:$clickOncePackagePath -frameworkPath:$frameworkPackagePath -packageZipPath:$packageZipDrop -source:$sourcePath -webroot:$webroot -log:$log >> $innerlog

write-output "Updating Metadata Resources File."
$UpdateResourcesLog = join-path $LogDir "update_Resources_$datetime.log"
$ResourceConfig = @{"Common.BinDir"= $metadataPackagePath; "Infrastructure.WebRoot"= $webroot}
$ResourceBase64Config = ConvertTo-Json $ResourceConfig
$ResourceBase64Config = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($ResourceBase64Config))
$argumentList = '–config:"$ResourceBase64Config" –log:"$UpdateResourcesLog"'

$Resourceslog=join-path $LogDir "update_ResourcesOutPut_$datetime.log"
  
if(!(Test-Path $Resourceslog)){
    New-Item -ItemType file $Resourceslog -Force
}

invoke-Expression "$PSScriptRoot\DeployResources.ps1 $argumentList" >> $ResoucesLog

write-output "Updating Metadata Reference File."
Update-PackageReferenceFile -metadataPath:$metadataPackagePath -packageZipPath:$(join-path $packageZipDrop "MetadataReferenceApp.zip")
Update-PackageReferenceFile -metadataPath:$metadataPackagePath -packageZipPath:$(join-path $packageZipDrop "MetadataReferencePlat.zip")

write-output "Updating Additional File."
UpdateAdditionalFiles -webRoot:$webroot -packageDir:$metadataPackagePath

try
{
    $DeveloperBox = Get-DevToolsInstalled
    if(!($DeveloperBox))
    { 
        if(Test-Path "$PSScriptRoot\RemoveSymLinkAndNgenAssemblies.ps1")
        {
            Write-Output "Removing SymLink And NgenAssemblies..."
            invoke-Expression "$PSScriptRoot\RemoveSymLinkAndNgenAssemblies.ps1"   
        }
    }
}
 catch
{
    #always generate symlink point to the none staging folder of aos services
    GenerateSymLinkNgen -webroot:$webroot -metadataPackagePath:$(Get-AOSPackageDirectory)
}

write-output "Creating Metadata Module Installation Info."
try
{
    $CommonBin = $(Get-CommonBinDir)
    #using Add-Type which will auto load all referenced dll
    Add-Type -Path "$CommonBin\bin\Microsoft.Dynamics.AX.AXInstallationInfo.dll"
    [Microsoft.Dynamics.AX.AXInstallationInfo.AXInstallationInfo]::ScanMetadataModelInRuntimePackage($metadataPackagePath)
    
}
catch
{
    write-warning "Failed to create metadata module installation record"
}

$enddatetime=get-date
"******************************************************" >> $log
"** Completed the package deployment at $enddatetime **" >> $log
"******************************************************" >> $log
"" >> $log
$duration=$enddatetime-$startdatetime
"Package deployment duration:" >> $log 
"$duration" >> $log 
    
"" >> $log
"******************************************************" >> $log
"Packages installed in this session:" >> $log
"******************************************************" >> $log
foreach($pkg in $Global:installedPackages){
    "$pkg" >> $log
}

""
"******************************************************"
"Packages installed in this session:"
"******************************************************"
foreach($pkg in $Global:installedPackages){
    "$pkg"
}
""
"installation log file: $log"

# SIG # Begin signature block
# MIIkDwYJKoZIhvcNAQcCoIIkADCCI/wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBr7o5VZXBagdiR
# kV2f7ocKIRBRBYWk5peWeIw9EM+dz6CCDYIwggYAMIID6KADAgECAhMzAAAAww6b
# p9iy3PcsAAAAAADDMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTcwODExMjAyMDI0WhcNMTgwODExMjAyMDI0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC7V9c40bEGf0ktqW2zY596urY6IVu0mK6N1KSBoMV1xSzvgkAqt4FTd/NjAQq8
# zjeEA0BDV4JLzu0ftv2AbcnCkV0Fx9xWWQDhDOtX3v3xuJAnv3VK/HWycli2xUib
# M2IF0ZWUpb85Iq2NEk1GYtoyGc6qIlxWSLFvRclndmJdMIijLyjFH1Aq2YbbGhEl
# gcL09Wcu53kd9eIcdfROzMf8578LgEcp/8/NabEMC2DrZ+aEG5tN/W1HOsfZwWFh
# 8pUSoQ0HrmMh2PSZHP94VYHupXnoIIJfCtq1UxlUAVcNh5GNwnzxVIaA4WLbgnM+
# Jl7wQBLSOdUmAw2FiDFfCguLAgMBAAGjggF/MIIBezAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUpxNdHyGJVegD7p4XNuryVIg1Ga8w
# UQYDVR0RBEowSKRGMEQxDDAKBgNVBAsTA0FPQzE0MDIGA1UEBRMrMjMwMDEyK2M4
# MDRiNWVhLTQ5YjQtNDIzOC04MzYyLWQ4NTFmYTIyNTRmYzAfBgNVHSMEGDAWgBRI
# bmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEt
# MDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAE2X
# TzR+8XCTnOPVGkucEX5rJsSlJPTfRNQkurNqCImZmssx53Cb/xQdsAc5f+QwOxMi
# 3g7IlWe7bn74fJWkkII3k6aD00kCwaytWe+Rt6dmAA6iTCXU3OddBwLKKDRlOzmD
# rZUqjsqg6Ag6HP4+e0BJlE2OVCUK5bHHCu5xN8abXjb1p0JE+7yHsA3ANdkmh1//
# Z+8odPeKMAQRimfMSzVgaiHnw40Hg16bq51xHykmCRHU9YLT0jYHKa7okm2QfwDJ
# qFvu0ARl+6EOV1PM8piJ858Vk8gGxGNSYQJPV0gc9ft1Esq1+fTCaV+7oZ0NaYMn
# 64M+HWsxw+4O8cSEQ4fuMZwGADJ8tyCKuQgj6lawGNSyvRXsN+1k02sVAiPGijOH
# OtGbtsCWWSygAVOEAV/ye8F6sOzU2FL2X3WBRFkWOCdTu1DzXnHf99dR3DHVGmM1
# Kpd+n2Y3X89VM++yyrwsI6pEHu77Z0i06ELDD4pRWKJGAmEmWhm/XJTpqEBw51sw
# THyA1FBnoqXuDus9tfHleR7h9VgZb7uJbXjiIFgl/+RIs+av8bJABBdGUNQMbJEU
# fe7K4vYm3hs7BGdRLg+kF/dC/z+RiTH4p7yz5TpS3Cozf0pkkWXYZRG222q3tGxS
# /L+LcRbELM5zmqDpXQjBRUWlKYbsATFtXnTGVjELMIIHejCCBWKgAwIBAgIKYQ6Q
# 0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5
# WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQD
# Ex9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4
# BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe
# 0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato
# 88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v
# ++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDst
# rjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN
# 91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4ji
# JV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmh
# D+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbi
# wZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8Hh
# hUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaI
# jAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTl
# UAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNV
# HQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQF
# TuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29m
# dC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNf
# MjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5t
# aWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNf
# MjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcC
# ARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnlj
# cHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5
# AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oal
# mOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0ep
# o/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1
# HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtY
# SWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInW
# H8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZ
# iWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMd
# YzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7f
# QccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKf
# enoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOpp
# O6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZO
# SEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCFeMwghXfAgEBMIGVMH4xCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jv
# c29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAADDDpun2LLc9ywAAAAAAMMw
# DQYJYIZIAWUDBAIBBQCggdIwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEIbUj0a
# S7uAPZfNxdoXBOTn8Kmfy/TTpeuzOUZheLmMMGYGCisGAQQBgjcCAQwxWDBWoDiA
# NgBJAG4AcwB0AGEAbABsAE0AZQB0AGEAZABhAHQAYQBQAGEAYwBrAGEAZwBlAHMA
# LgBwAHMAMaEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAto/XhHQprZtD08g9JKb03hxtNlk59Nc/IaB0PGXjijF9I+l+7Qi8UCU/
# ME+J5ar1MA257/Xk9aHV+KAW90oNYRDl0HJbhgXYaESOKix75fcKXLcFxgY15m30
# quCf3xXTMuTSxr7lgrj4v/gQW9PsMMFYTMc28n88hXkQfL/a+uy8WCde7oJqCwpi
# cxkbeNtWFlxAglnOQ1klEUxP/hVYEibi8maadEZsQPvCnbpFwasIxRfps48Cje6X
# 5YoynaInQdBAfWdH6W31QsyESsC1PegB/xP+OxXP0Bh167hc/HyJA44pwAB8CYu6
# Au7vMQpeIGorajVbiK8y7ZxJRgOnK6GCE0kwghNFBgorBgEEAYI3AwMBMYITNTCC
# EzEGCSqGSIb3DQEHAqCCEyIwghMeAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggE8Bgsq
# hkiG9w0BCRABBKCCASsEggEnMIIBIwIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCC2aLkjfQmmsnoyNL8XzegL/5henk9BvgkQ8T7e9dCgtQIGWdMNviet
# GBMyMDE3MTAwNDExMDA0Mi4xODlaMAcCAQGAAgPnoIG4pIG1MIGyMQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMQwwCgYDVQQLEwNBT0MxJzAlBgNV
# BAsTHm5DaXBoZXIgRFNFIEVTTjo4NDNELTM3RjYtRjEwNDElMCMGA1UEAxMcTWlj
# cm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCDs0wggZxMIIEWaADAgECAgphCYEq
# AAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVa
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhL
# LF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4
# CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLB
# xKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJN
# QFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc08
# 5y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJ
# KwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkG
# CSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8E
# BTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRP
# ME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEww
# SgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMv
# TWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8G
# CSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBM
# AGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTAN
# BgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp
# /vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBA
# QZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZ
# qbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a
# 21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc
# +R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGq
# BooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cx
# B6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kq
# VDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8Z
# QU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHe
# MMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSI
# SRIwggTZMIIDwaADAgECAhMzAAAAqVRw2XnAhGXiAAAAAACpMA0GCSqGSIb3DQEB
# CwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTE2MDkwNzE3NTY1
# M1oXDTE4MDkwNzE3NTY1M1owgbIxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xDDAKBgNVBAsTA0FPQzEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# Ojg0M0QtMzdGNi1GMTA0MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArJSFGKblVtOd
# 3wNnLtuYkUePlYlyTZp08zRA3msRp9THkn4O/581On+nZIxxm2HFGVk+lF2RL07A
# 7cFAbicHkdTlrPYePM5QEVMnaITS0makH24deymLJuMJrnTnTPyfg7dGDdsVqQ37
# V/ezmxDeDBykTRrDliRGNimQXN4dR9aXP0KNB/+oLyeO6xIQsUdC9wS9OTbExbvA
# 7La8joGcyd2yQDw9o+sbvTB1/lsFcx0UMRHU8Dq/7NET3kTJxP5I4VfELngIFX7z
# RQY2Sba1/VgdEd2IZANCEDnvrlMWRhFbXH0SWndIdnApYSEak1OcImlunLR5eo5M
# OIQVGWxfoQIDAQABo4IBGzCCARcwHQYDVR0OBBYEFA/VQfu78530vklS2ow3V85k
# D/N9MB8GA1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0w
# S6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYI
# KwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWlj
# VGltU3RhUENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAww
# CgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggEBAAiZGKUHiy9yJHUsjiCEAv0K
# oa8O4bAyEYaqxYYgnbvoRDuVzLU654tGpRPTjCAbqDpXHBX3c22NC7IHRW6GRXYk
# Rrp0TPE2b1KdtuTklIzJKauJqr5ygtO6m1WroII54Bku2BGtRYkDS8Av4gCeuHuH
# 28rXdbguBLSMkzeKHiZE5NlBZY7RQrleExC8GWd1u86EqekfjnvPG5S4OV1tV1ns
# Cn7G1pUNO+f6iC9WrFUEUHJnP7IAA8OOwvw+yJWr4NRntqY0bbRgCLJCid5/YNpY
# IbzTjDgyU/IKzNvfJLcA65NKPwl6NDtLwHNralKEU6GbBERZYUKtcvBAwG78mrKh
# ggN3MIICXwIBATCB4qGBuKSBtTCBsjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEMMAoGA1UECxMDQU9DMScwJQYDVQQLEx5uQ2lwaGVyIERTRSBF
# U046ODQzRC0zN0Y2LUYxMDQxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFNlcnZpY2WiJQoBATAJBgUrDgMCGgUAAxUAXTq/Vr3hDynKcg5k93U7eBoi6/Sg
# gcEwgb6kgbswgbgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# DDAKBgNVBAsTA0FPQzEnMCUGA1UECxMebkNpcGhlciBOVFMgRVNOOjI2NjUtNEMz
# Ri1DNURFMSswKQYDVQQDEyJNaWNyb3NvZnQgVGltZSBTb3VyY2UgTWFzdGVyIENs
# b2NrMA0GCSqGSIb3DQEBBQUAAgUA3X8nGDAiGA8yMDE3MTAwNDA5MjMzNloYDzIw
# MTcxMDA1MDkyMzM2WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDdfycYAgEAMAoC
# AQACAhJbAgH/MAcCAQACAhkCMAoCBQDdgHiYAgEAMDYGCisGAQQBhFkKBAIxKDAm
# MAwGCisGAQQBhFkKAwGgCjAIAgEAAgMegJihCjAIAgEAAgMehIAwDQYJKoZIhvcN
# AQEFBQADggEBADkiHKEzSk9aTIcusfNcx9t8H0loNVsWkFJf4yCiBj1aJ01cEpQe
# hE0PDXuGg1gF9ToBosRxTnM25KdorJJF7UARTJ7DyYrud06H7egB96kpAUw0Te3r
# p+qktqjLm23/63Cb7I3x7/1bzR8Bsod8VLsyzp9p7hLrKIEmBlMI/GfwGWVGB/Tk
# R35N+c5r0g0mFymaew6k0V3d3UHMQJSMQk7S/s4oH66kdyXdOenaXydQBSknA2oD
# Aahdv3e0OGdeK6tFboURdycURHjKlvu3RL9eQGThLC8uJJ2Kd7SjkDxnHR9l7WbY
# wHTFQYwfYg97BxlJDIf5RPao8o5zy9j4hZ4xggL1MIIC8QIBATCBkzB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAKlUcNl5wIRl4gAAAAAAqTANBglg
# hkgBZQMEAgEFAKCCATIwGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqG
# SIb3DQEJBDEiBCAQtbp+ivw4iQFpMqEJVtc21LpHyc39lH4881bZXIkY7jCB4gYL
# KoZIhvcNAQkQAgwxgdIwgc8wgcwwgbEEFF06v1a94Q8pynIOZPd1O3gaIuv0MIGY
# MIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAACpVHDZecCE
# ZeIAAAAAAKkwFgQUFV1cuLB/UHkneMOoEobDaDYB8w4wDQYJKoZIhvcNAQELBQAE
# ggEAYgmwaRU+Jurc9IuwfneGsN3IYcO5qZXRM3bjIWlL9+kmeFGQ3J7QLXvpKXjc
# 0QwWPxhZRQotCf6uxAlEEssXyNOfkwz74OUY3qBvbTA8NCy4Ic9wa0e5EQmBhA/O
# g/tDfDtR8VI13B3ee/ZPfZcae6UHABW7l+YcyBJ4IxwoHujC/IQ+rsgr8AIefb1b
# Z7YhtpZqQ00Ksy43ow8WSzkXOqhgMX9Lj6NIgKW2CVOEfcSZyvfatoN5bI6YSeOS
# U9r5Ljny5K9Dy/t7rcJ5C1xmOZiU3Um6KHXXgIqMdXI1PXxy50jtHAZU2DpQSUJC
# Kkcjh3ySZL5mUQPZKFmXWFyutw==
# SIG # End signature block
