﻿####################################################################################
####################################################################################
## ValidateAOS.ps1
## Validate AOS deployment
## Date: 09/29/2015
##
####################################################################################
####################################################################################
[CmdletBinding()]
Param(
   [Parameter(Mandatory = $true)]
   [string]$InputXml,
   [Parameter(Mandatory = $false)]
   [string]$CredentialsXml,
   [Parameter(Mandatory = $true)]
   [string]$Log
)

Import-Module "$PSScriptRoot\AosCommon.psm1" -Force -DisableNameChecking
Initialize-Log $Log

####################################################################################
## Helper Functions
####################################################################################

## Append XML Rows to Template
function Append-RowToXML
{
    [CmdletBinding()]
    Param(
       [Parameter(Mandatory = $false)]
       [string]$TestName,
       [Parameter(Mandatory = $false)]
       [string]$TestType,
       [Parameter(Mandatory = $false)]
       [string]$TestResult,
       [Parameter(Mandatory = $false)]
       [string]$RawResult,
       [Parameter(Mandatory = $false)]
       [string]$TimeStamp,
       [Parameter(Mandatory = $true)]
       [xml]$xmlTemplate
    )

    Write-Log "Getting existing rows from XML Template"
    $rows = $xmlTemplate.SelectSingleNode('CollectionResult/TabularResults/TabularData/Rows')
    Write-Log "Creating new row"
    $row = $xmlTemplate.CreateElement('ArrayOfStrings')
    $column = $xmlTemplate.CreateElement('string')#TestName
    $column.InnerText = $TestName
    $row.AppendChild($column)
    Write-Log "Adding column value: $TestName"
    $column = $xmlTemplate.CreateElement('string')#TestType
    $column.InnerText = $TestType
    $row.AppendChild($column)
    Write-Log "Adding column value: $TestType"
    $column = $xmlTemplate.CreateElement('string')#TestResult
    $column.InnerText = $TestResult
    $row.AppendChild($column)
    Write-Log "Adding column value: $TestResult"
    $column = $xmlTemplate.CreateElement('string')#RawResult
    $column.InnerText = $RawResult
    $row.AppendChild($column)
    
    $column = $xmlTemplate.CreateElement('string')#TimeStamp
    $column.InnerText = $TimeStamp
    $row.AppendChild($column)
    $rows.AppendChild($row)
    Write-Log "Adding column value: $TimeStamp"
    $xmlTemplate.CollectionResult.TabularResults.TabularData.AppendChild($rows)
    $xmlTemplate.Save($xmlTemplate)
    Write-Log "Saved rows to XML Template"
}

####################################################################################
## Validation Functions
####################################################################################

## Validate that all dependencies for AOS can be resolved
function Validate-AosDependencies($AosWebrootPath, $OutputPath, $Log, [ref]$TestResult)
{        
    $LoadErrorLog = join-path $OutputPath -ChildPath "AssemblyResolveErrors_$([System.DateTime]::Now.ToString("yyyy-MM-dd-HH_mm_ss")).csv"

    Write-Log "Dependency resolution error details will be written to $LoadErrorLog"
    
    Write-Log "Loading AOS web.config from $AosWebrootPath"
    [xml]$WebConfig = Get-Content "$(join-path $AosWebrootPath "web.config")"    
    $PackagesPathKey = $WebConfig.configuration.appSettings.add | where { $_.key -eq 'Aos.PackageDirectory' }

    Write-Log "Scanning for *.dll in $AosWebrootPath"
    $Assemblies = Get-ChildItem $AosWebrootPath -Recurse -Include "*.dll"

    if ($PackagesPathKey -ne $null)
    {
        Write-Log "Scanning for *.dll in $($PackagesPathKey.Value)"
        $Assemblies += Get-ChildItem $PackagesPathKey.Value -Recurse -Include "*.dll"
    }

    Write-Log "Creating a hash set of all found assembly names"
    $AssemblyNameHash = @{}
    foreach ($Assembly in $Assemblies)
    {
        if (!$AssemblyNameHash.ContainsKey($Assembly.Name))
        {
            $AssemblyNameHash[$Assembly.Name] = @($Assembly.FullName)
        }
        else
        {
            $AssemblyNameHash[$Assembly.Name] += $Assembly.FullName
        }
    }

    $ExclusionList = @("MS.Dynamics.Commerce.Client.Pos.FunctionalTests.dll",
"MS.Dynamics.Commerce.RetailProxy.Employee.CRT.Sqlite.FunctionalTests.dll",
"MS.Dynamics.Commerce.RetailProxy.Employee.CRT.SqlServer.FunctionalTests.dll",
"MS.Dynamics.Commerce.RetailProxy.Employee.DemoMode.SqlServer.FunctionalTests.dll",
"Microsoft.Dynamics.Retail.RetailServer.dll",
"Microsoft.Dynamics.Commerce.Runtime.Client.dll",
"Microsoft.Dynamics.Commerce.Runtime.Services.dll",
"Microsoft.Dynamics.Commerce.Runtime.TransactionService.dll",
"Microsoft.Dynamics.Commerce.Runtime.Workflow.dll"
"Cfx.CloudStorage.dll",
"Cfx.CommunicationFramework.dll",
"Cfx.Contracts.dll",
"Cfx.RuntimeWrapper.dll",
"DataContracts.NSD.dll",
"Microsoft.Dynamics.AX.ExchangeIntegration.dll",
"Microsoft.Dynamics.AX.Framework.Xlnt.XppParser.Tests.dll",
"Microsoft.Dynamics.AX.Metadata.Upgrade.Rules.dll",
"Microsoft.Dynamics.AX.Services.Tracing.Data.dll",
"Microsoft.Dynamics.AX.Services.Tracing.TraceParser.dll",
"Microsoft.Dynamics.AX.Servicing.SCDP.dll",
"Microsoft.Dynamics.AX.Servicing.SCDPBundling.dll",
"Microsoft.Dynamics.Clx.DbRestorePlugin.dll",
"Microsoft.Dynamics.Clx.DbSyncPlugin.dll",
"Microsoft.Dynamics.Clx.DbSyncPluginContext.dll",
"Microsoft.Dynamics.Clx.DummyPlugin.dll",
"Microsoft.Dynamics.Clx.DummyPluginContext.dll",
"Microsoft.Dynamics.Framework.Tools.ApplicationExplorer.dll",
"Microsoft.Dynamics.Framework.Tools.AutomationObjects.dll",
"Microsoft.Dynamics.Framework.Tools.BuildTasks.dll",
"Microsoft.Dynamics.Framework.Tools.Core.dll",
"Microsoft.Dynamics.Framework.Tools.Designers.dll",
"Microsoft.Dynamics.Framework.Tools.FormControlExtension.dll",
"Microsoft.Dynamics.Framework.Tools.Installer.dll",
"Microsoft.Dynamics.Framework.Tools.LabelEditor.dll",
"Microsoft.Dynamics.Framework.Tools.LanguageService.dll",
"Microsoft.Dynamics.Framework.Tools.LanguageService.Parser.dll",
"Microsoft.Dynamics.Framework.Tools.MetaModel.Core.dll",
"Microsoft.Dynamics.Framework.Tools.MetaModel.dll",
"Microsoft.Dynamics.Framework.Tools.ProjectSupport.dll",
"Microsoft.Dynamics.Framework.Tools.ProjectSystem.dll",
"Microsoft.Dynamics.Framework.Tools.Reports.DesignTime.dll",
"Microsoft.DynamicsOnline.Deployment.dll",
"Microsoft.DynamicsOnline.Infrastructure.dll",
"Microsoft.DynamicsOnline.Infrastructure.Providers.dll",
"Microsoft.ServiceHosting.Tools.DevelopmentFabric.dll",
"Microsoft.ServiceHosting.Tools.DevelopmentFabric.Service.dll",
"Microsoft.TeamFoundation.Client.dll",
"Microsoft.TeamFoundation.VersionControl.Client.dll",
"Microsoft.VisualStudio.ExtensionManager.dll",
"Microsoft.VisualStudio.Services.Client.dll",
"Microsoft.VisualStudio.TestPlatform.Extensions.VSTestIntegration.dll",
"Ms.Dynamics.Performance.Framework.dll",
"MS.Dynamics.Test.BIAndReporting.PowerBI.UnitTests.dll"
"MS.Dynamics.TestTools.CloudCommonTestUtilities.dll",
"MS.Dynamics.TestTools.TaskRecording.XppCodeGenerator.dll",
"MS.Dynamics.TestTools.TestLog.dll",
"MS.Dynamics.TestTools.UIHelpers.Core.dll",
"RoleCommon.dll",
"MS.Dynamics.TestTools.ApplicationFoundationUIHelpers.dll",
"Microsoft.Dynamics.AX.Framework.BestPracticeFixerIntegration.dll",
"Microsoft.AnalysisServices.AdomdClient.dll",
"Microsoft.AnalysisServices.dll",
"Microsoft.AnalysisServices.DLL",
"Microsoft.Dynamics.Framework.Tools.Configuration.dll",
"MS.Dynamics.Platform.Integration.SharePoint.Tests.dll",
"MS.Dynamics.TestTools.ApplicationSuiteUIHelpers.dll",
"Microsoft.SqlServer.AzureStorageEnum.dll",
"Microsoft.SqlServer.Management.SmoMetadataProvider.dll",
"Microsoft.SqlServer.Management.Utility.dll",
"Microsoft.SqlServer.OlapEnum.dll",
"Microsoft.Dynamics.Retail.DynamicsOnlineConnector.portable.dll",
"DataAccess.dll",
"SystemSettings.dll",
"BusinessLogic.dll",
"ButtonGrid.dll",
"POSProcesses.dll"
)

$ReferenceExclusionList = @(
"Microsoft.Dynamics.AX.Framework.Analytics.Deploy.dll#Microsoft.SqlServer.DTSPipelineWrap",
"Microsoft.Dynamics.AX.Framework.Analytics.Deploy.dll#Microsoft.SqlServer.DTSRuntimeWrap",
"Microsoft.Dynamics.AX.Framework.Analytics.Deploy.dll#Microsoft.SqlServer.ManagedDTS"
)


    $CurrentAssemblyWithErrors = ""

    $RawErrors = @()
    $RawWarnings = @()

    Add-Content -Path $LoadErrorLog -Value "Assembly;FullPath;FQ name;Unresolved reference FQ name;Error type"

    foreach ($Assembly in $Assemblies)
    {
        try
        {    
            $LoadedAssembly = [System.Reflection.Assembly]::LoadFile($Assembly.FullName)
            $ReferenceList = $LoadedAssembly.GetReferencedAssemblies()
        }
        catch
        {            
            Add-Content -Path $LoadErrorLog -Value "$($Assembly.Name);$($Assembly.FullName);Loading failed;Loading failed;LoadFailure"                
            $RawWarnings += "$($Assembly.Name) -> Loading failed;"
            continue
        }

        foreach ($Reference in $ReferenceList)
        {    
            if (!$AssemblyNameHash.ContainsKey("$($Reference.Name).dll"))
            {
                try
                {
                    [System.Reflection.Assembly]::Load($Reference.FullName) | Out-Null
                }
                catch
                {
                    $ErrorType = "ResolveFailure"
                    if (($Reference.Name -like "System.*" -or $Reference.Name -like "System") -and $Reference.Version -eq "2.0.5.0")
                    {
                        continue
                    }
                    elseif ($ExclusionList.Contains($Assembly.Name))
                    {
                        $ErrorType = "ResolveWarning - Exclusion"
                        Write-Log "Warning: Failed to resolve reference $($Reference.FullName) for assembly $($Assembly.FullName). The assembly was found in exclusion list."                                                    
                        $RawWarnings += "$($Assembly.Name) -> $($Reference.FullName);"                        
                    }
                    elseif ($ReferenceExclusionList.Contains($Assembly.Name + "#" + $Reference.Name))
                    {
                        $ErrorType = "ResolveWarning - Exclusion"
                        Write-Log "Warning: Failed to resolve reference $($Reference.FullName) for assembly $($Assembly.FullName). The referenced assembly was found in exclusion list."                        
                        $RawWarnings += "$($Assembly.Name) -> $($Reference.FullName);"
                    }
                    else
                    {
                        Write-Log "Error: Failed to resolve reference $($Reference.FullName) for assembly $($Assembly.FullName)"
                        $RawErrors += "$($Assembly.Name) -> $($Reference.FullName);"
                    }

                    $CurrentAssemblyWithErrors = $Assembly.Name
                    Add-Content -Path $LoadErrorLog -Value "$($Assembly.Name);$($Assembly.FullName);$($LoadedAssembly.FullName);$($Reference.FullName);$ErrorType"                                        
                }
            }
        }
    }
    
    Write-Log "Dependency scan finished."
    if($RawErrors.Length -gt 0)
    {
        Write-Log "Dependency resolution failed for some assemblies. Check test results or csv file.."
        $returnProperties = @{Result=0;RawResults=(($RawErrors + $RawWarnings) | Out-String);TimeStamp=(Get-Date).ToString()}
    }
    else
    {
        Write-Log "Dependency resolution passed."

        if ($RawWarnings.Length -gt 0)
        {
            Write-Log "There were warnings: dependency resolution failed for some assemblist from exclusion list"
        }

        $returnProperties = @{Result=1;RawResults=($RawWarnings | Out-String);TimeStamp=(Get-Date).ToString()}
    }

    $resultObject = New-Object PsObject -Property $returnProperties
    $TestResult.Value = $resultObject
}


## Validate endpoint sending HTTP request to configured endpoint 
function Validate-Endpoint{ 
     [CmdletBinding()] 
    Param( 
     [Parameter(Mandatory = $true)] 
     [string]$EndPointUrl 
     ) 
 
     [bool]$result = $false 
     [string]$rawResult 
     [string]$timestamp 
 
     try{ 
         Write-Log "Connecting to '$EndPointUrl'"
         $CurrentTime = (Get-Date).ToUniversalTime() 
         $webRequest = Invoke-WebRequest -Uri $EndPointUrl -UseBasicParsing 
         if($webRequest.StatusCode -eq 200){ 
             $result = $true 
             $UrlTime = [DateTime]::Parse($webRequest.Headers.Date).ToUniversalTime() 
             $rawResult = ('HttpResult: ' + $webRequest.StatusCode.ToString() + '; PingTime(ms): ' + ($CurrentTime - $UrlTime).TotalMilliseconds).ToString() 
             $timestamp = (Get-Date).ToString() 
             Write-Log "Web request returned - $rawResult"
         } 
     } 
     catch{ 
         $rawResult = $_.Exception 
         $timestamp = (Get-Date).ToString() 
         Write-Log "ERROR: $($_.Exception) CALLSTACK: $_"
     } 
 
     if($result){ 
         $returnProperties = @{ 
             Result=1; 
            RawResults=$rawResult; 
            TimeStamp=$timestamp 
         } 
     } 
     else{ 
         $returnProperties = @{ 
             Result=0; 
            RawResults=$rawResult; 
            TimeStamp=$timestamp 
         } 
     } 
     $resultObject = New-Object PsObject -Property $returnProperties 
     return $resultObject 
} 
 
## Validate install Files from a manifest file 
function Validate-Install{ 
     [CmdletBinding()] 
    Param( 
     [Parameter(Mandatory = $true)] 
     [string]$InstallPath, 
     [Parameter(Mandatory = $false)] 
     [string]$ManifestPath 
     ) 
 
     [bool]$result = $false 
     [string]$rawResult 
     [string]$timestamp 
 
     try{ 
         Write-Log "Validating Install at '$InstallPath'"
         if(Test-Path -Path $InstallPath) 
         { 
             Write-Log "Comparing '$InstallPath' to manifest"
             [System.Array]$installedfiles = @() 
             $installedFilesRaw = Get-ChildItem -Path $InstallPath -Recurse | Where {$_.PSIsContainer -eq $false} | Select-Object -Property Name 
            foreach($file in $installedFilesRaw){ 
                $installedfiles += $file.Name 
             } 
 
             if(Test-Path -Path $ManifestPath){ 
                 $manifestFiles = Get-Content -Path $ManifestPath 
                 $fileCompare = Compare-Object -ReferenceObject $manifestFiles -DifferenceObject $installedFiles -Property Name -PassThru 
                 $timestamp = (Get-Date).ToString() 
                 if($fileCompare -eq $null) 
                 { 
                     $rawResult = "Installed file ARE a match to the manifest" 
                     Write-Log "$rawResult"
                     $result = $true 
                 } 
                 else 
                 { 
                     $rawResult = ("{0} Files are missing." -f $fileCompare.Count ) 
                     Write-Log "$rawResult"
                 } 
             } 
             else{ 
                Throw "$ManifestPath does not exist." 
             } 
         } 
         else{ 
            Throw "$InstallPath does not exist." 
         } 
     } 
     catch{ 
         $rawResult = $_.Exception 
         $timestamp = (Get-Date).ToString() 
         Write-Log "ERROR: $($_.Exception) CALLSTACK: $_"
     } 
 
     if($result){ 
         $returnProperties = @{ 
             Result=1; 
            RawResults=$rawResult; 
            TimeStamp=$timestamp 
         } 
     } 
     else{ 
         $returnProperties = @{ 
             Result=0; 
            RawResults=$rawResult; 
            TimeStamp=$timestamp 
         } 
    } 
     $resultObject = New-Object PsObject -Property $returnProperties 
     return $resultObject 
} 
 
## Validate service is running 
function Validate-Service{ 
    [CmdletBinding()] 
    Param( 
     [Parameter(Mandatory = $true)] 
     [string]$ServiceName, 
     [Parameter(Mandatory = $true)] 
     [ValidateSet("Running","Stopped","Paused")] 
     [string]$CurrentState 
     ) 
 
     [bool]$result = $false 
     [string]$rawResult 
     [string]$timestamp 
 
     try{ 
         Write-Log "Validating Service: '$ServiceName' is $CurrentState"
         $thisService = Get-Service -Name $ServiceName 
         $timestamp = (Get-Date).ToString() 
         $rawResult = ("ServiceName: {0}; DisplayName: {1}; Status: {2}" -f $thisService.Name, $thisService.DisplayName, $thisService.Status) 
         if($thisService.Status.ToString() -eq $CurrentState) 
         { 
            $result = $true 
         } 
         Write-Log "Service: $ServiceName is $($thisService.Status)"
 
     } 
     catch{ 
         $rawResult = $_.Exception 
         $timestamp = (Get-Date).ToString() 
         Write-Log "ERROR: $($_.Exception) CALLSTACK: $_"
     } 
 
     if($result){ 
         $returnProperties = @{ 
             Result=1; 
            RawResults=$rawResult; 
            TimeStamp=$timestamp 
         } 
     } 
     else{ 
         $returnProperties = @{ 
             Result=0; 
            RawResults=$rawResult; 
            TimeStamp=$timestamp 
         } 
     } 
     $resultObject = New-Object PsObject -Property $returnProperties 
     return $resultObject 
} 
 
## Validate appPool is started 
function Validate-AppPool{ 
    [CmdletBinding()] 
    Param( 
     [Parameter(Mandatory = $true)] 
     [string]$AppPoolName, 
     [Parameter(Mandatory = $true)] 
     [ValidateSet("Started","Stopped")] 
     [string]$CurrentState 
     ) 
 
     [bool]$result = $false 
     [string]$rawResult 
     [string]$timestamp 
 
     try{ 
         Write-Log "Validating AppPool: '$AppPoolName' is $CurrentState"
         Get-WebAppPoolState 
         $appPoolStatus = Get-WebAppPoolState -Name $AppPoolName 
         $timestamp = (Get-Date).ToString() 
         $rawResult = ("AppPoolName: {0}; Status: {1}" -f $AppPoolName, $appPoolStatus) 
         if($appPoolStatus.Value -eq $CurrentState) 
         { 
            $result = $true 
         } 
         Write-Log "AppPool: $AppPoolName is $($appPoolStatus.Value)"
     } 
     catch{ 
         $rawResult = $_.Exception 
         $timestamp = (Get-Date).ToString() 
         Write-Log "ERROR: $($_.Exception) CALLSTACK: $_"
     } 
 
     if($result){ 
         $returnProperties = @{ 
             Result=1; 
            RawResults=$rawResult; 
            TimeStamp=$timestamp 
         } 
     } 
     else{ 
         $returnProperties = @{ 
             Result=0; 
            RawResults=$rawResult; 
            TimeStamp=$timestamp 
         } 
     } 
     $resultObject = New-Object PsObject -Property $returnProperties 
     return $resultObject 
} 




####################################################################################
## Parameter Setting
####################################################################################
Write-Log "Setting DVT execution parameters"

if(Test-Path -Path $InputXML)
{
    Write-Log "Parsing the xml for parameters/settings"
    [xml]$DVTParams = Get-Content -Path $InputXML
    [string]$ServiceName = $DVTParams.DVTParameters.ServiceName    
    [string]$AosWebrootPath = $DVTParams.DVTParameters.AosWebRootPath    
    [string]$XmlOutputPath = $DVTParams.DVTParameters.OutputPath    
	[string]$endPoint = $DVTParams.DVTParameters.EndPoint #Infrastructure.HostUrl
    [string]$installPath = $DVTParams.DVTParameters.InstallPath
	[string]$manifestFile = $DVTParams.DVTParameters.ManifestPath
	[string]$ServiceState = $DVTParams.DVTParameters.ServiceState
	[string]$AppPoolName = $DVTParams.DVTParameters.AppPoolName
	[string]$AppPoolState = $DVTParams.DVTParameters.AppPoolState
    [string]$BatchService = $DVTParams.DVTParameters.BatchService
}
else
{
    throw "Unable to parse settings from service model. Xml doesnt exist at: $InputXML"
}

if(-not ([string]::IsNullOrEmpty($CredentialsXml)))
{
    Write-Log "Parsing the CredentialsXml"
    if(Test-Path -Path $CredentialsXml)
    {
        Write-Log "Parsing the xml for local credentials"
        $localCredentials = Import-Clixml -Path $CredentialsXml
        [string]$UserName = $localCredentials.GetNetworkCredential().UserName
        [string]$UserPassword = $localCredentials.GetNetworkCredential().Password
    }
    else
    {
        throw "Unable to parse credentials from service model. Xml doesnt exist at: $CredentialsXML"
    }
}

Write-Log "Setting diagnostics-related parameters"
[string]$CollectorName = "$($ServiceName).DVT"
[string]$CollectorType = 'PowerShellCollector'
[string]$TargetName = (hostname)

if(-not (Test-Path -Path $XmlOutputPath))
{
    Write-Log "Creating diagnostics result directory at $XmlOutputPath"
    New-Item -Path $XmlOutputPath -Type Container | Out-Null
}

[string]$XMLFilePath = Join-Path -Path $XmlOutputPath -ChildPath "$([System.DateTime]::Now.ToFileTimeUtc())_$($ServiceName)DVTResults.xml"

####################################################################################
## Diagnostics Collector XML Template
####################################################################################
[xml]$xmlTemplate = @"
<?xml version="1.0"?>
<CollectionResult xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <CollectorName>$CollectorName</CollectorName>
  <CollectorType>$CollectorType</CollectorType>
  <ErrorMessages />
  <TabularResults>
    <TabularData>
      <TargetName>$TargetName</TargetName>
      <Columns>
        <string>TestName</string>
        <string>TestType</string>
        <string>PassResult</string>
        <string>RawResult</string>
        <string>TimeStamp</string>
      </Columns>
      <Rows>
      </Rows>
    </TabularData>
  </TabularResults>
</CollectionResult>
"@

####################################################################################
## Main Execution
####################################################################################

Write-Log "Running validations for $ServiceName"
try
{
    #Dependency validation
    Write-Log "Validate-AosDependencies -AosWebrootPath $AosWebrootPath -OutputPath $XmlOutputPath -Log $Log"
    $dependenciesResult = New-Object PsObject
    Validate-AosDependencies -AosWebrootPath $AosWebrootPath -OutputPath $XmlOutputPath -Log $Log ([ref]$dependenciesResult)
    
    Append-RowToXML -TestName 'AOSService.Validate-AosDependencies' -TestType 'DVT' -TestResult $dependenciesResult.Result -RawResult $dependenciesResult.RawResults -TimeStamp $dependenciesResult.TimeStamp -xmlTemplate $xmlTemplate | Out-Null
    
     #End point validation 
     Write-Log "Validate-Endpoint -EndPointUrl" 
     $endpointResult = Validate-Endpoint -EndPointUrl $endPoint
 
     Append-RowToXML -TestName 'AOS.Validate-Endpoint' -TestType 'DVT' -TestResult $endpointResult.Result -RawResult $endpointResult.RawResults -TimeStamp $endpointResult.TimeStamp -xmlTemplate $xmlTemplate | Out-Null 

    $ValidateBatch = (![System.String]::IsNullOrWhiteSpace($DVTParams.DVTParameters.ValidateBatch) -and [System.Convert]::ToBoolean($DVTParams.DVTParameters.ValidateBatch))
    if ($ValidateBatch)
    {
        #AXBatch Service 
        Write-Log "Validate-Service -ServiceName $BatchService -CurrentState $ServiceState" 
        $serviceResult = Validate-Service -ServiceName $BatchService -CurrentState $ServiceState 

        Append-RowToXML -TestName 'AOS.Validate-Service' -TestType 'DVT' -TestResult $serviceResult.Result -RawResult $serviceResult.RawResults -TimeStamp $serviceResult.TimeStamp -xmlTemplate $xmlTemplate | Out-Null 
    } 

     #IIS AppPool Validation 
     Write-Log "Validate-AppPool -AppPoolName $AppPoolName -CurrentState $AppPoolState"
     $apppoolResult = Validate-AppPool -AppPoolName $AppPoolName -CurrentState $AppPoolState 

     Append-RowToXML -TestName 'AOS.Validate-AppPool' -TestType 'DVT' -TestResult $apppoolResult.Result -RawResult $apppoolResult.RawResults -TimeStamp $apppoolResult.TimeStamp -xmlTemplate $xmlTemplate | Out-Null 

    #Writing XML results
    Write-Log "Writing DVT results to $XMLFilePath"
    $xmlTemplate.InnerXml | Out-File -FilePath $XMLFilePath -Force -Encoding utf8

    [bool]$dvtResult = $endpointResult.Result -and $apppoolResult.Result
    if ($ValidateBatch)
    {
        $dvtResult = $dvtResult -and $serviceResult.Result
    }

}
catch
{
    Write-Exception $_
}

if($dvtResult)
{
    $exitProperties = @{'ExitCode'= 0}
    $exitObject = New-Object PsObject -Property $exitProperties
    Write-Log "DVT Script Completed, ExitCode: $($exitObject.ExitCode)"
    return $exitObject
}
else
{
    $exitProperties = @{'ExitCode'= 1; 'Message'="DVT Validation failed, see log: '$Log' for further details, and '$XMLFilePath' for test results"}
    $exitObject = New-Object PsObject -Property $exitProperties
    Write-Log "DVT Script Completed, ExitCode: $($exitObject.ExitCode)"
    throw $exitObject
}


# SIG # Begin signature block
# MIIj9wYJKoZIhvcNAQcCoIIj6DCCI+QCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBhdqcLFlnn/+bf
# xJ8zUJm5mciZOlXNp0qLPhlRYYQMS6CCDYIwggYAMIID6KADAgECAhMzAAAAww6b
# p9iy3PcsAAAAAADDMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTcwODExMjAyMDI0WhcNMTgwODExMjAyMDI0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC7V9c40bEGf0ktqW2zY596urY6IVu0mK6N1KSBoMV1xSzvgkAqt4FTd/NjAQq8
# zjeEA0BDV4JLzu0ftv2AbcnCkV0Fx9xWWQDhDOtX3v3xuJAnv3VK/HWycli2xUib
# M2IF0ZWUpb85Iq2NEk1GYtoyGc6qIlxWSLFvRclndmJdMIijLyjFH1Aq2YbbGhEl
# gcL09Wcu53kd9eIcdfROzMf8578LgEcp/8/NabEMC2DrZ+aEG5tN/W1HOsfZwWFh
# 8pUSoQ0HrmMh2PSZHP94VYHupXnoIIJfCtq1UxlUAVcNh5GNwnzxVIaA4WLbgnM+
# Jl7wQBLSOdUmAw2FiDFfCguLAgMBAAGjggF/MIIBezAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUpxNdHyGJVegD7p4XNuryVIg1Ga8w
# UQYDVR0RBEowSKRGMEQxDDAKBgNVBAsTA0FPQzE0MDIGA1UEBRMrMjMwMDEyK2M4
# MDRiNWVhLTQ5YjQtNDIzOC04MzYyLWQ4NTFmYTIyNTRmYzAfBgNVHSMEGDAWgBRI
# bmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEt
# MDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAE2X
# TzR+8XCTnOPVGkucEX5rJsSlJPTfRNQkurNqCImZmssx53Cb/xQdsAc5f+QwOxMi
# 3g7IlWe7bn74fJWkkII3k6aD00kCwaytWe+Rt6dmAA6iTCXU3OddBwLKKDRlOzmD
# rZUqjsqg6Ag6HP4+e0BJlE2OVCUK5bHHCu5xN8abXjb1p0JE+7yHsA3ANdkmh1//
# Z+8odPeKMAQRimfMSzVgaiHnw40Hg16bq51xHykmCRHU9YLT0jYHKa7okm2QfwDJ
# qFvu0ARl+6EOV1PM8piJ858Vk8gGxGNSYQJPV0gc9ft1Esq1+fTCaV+7oZ0NaYMn
# 64M+HWsxw+4O8cSEQ4fuMZwGADJ8tyCKuQgj6lawGNSyvRXsN+1k02sVAiPGijOH
# OtGbtsCWWSygAVOEAV/ye8F6sOzU2FL2X3WBRFkWOCdTu1DzXnHf99dR3DHVGmM1
# Kpd+n2Y3X89VM++yyrwsI6pEHu77Z0i06ELDD4pRWKJGAmEmWhm/XJTpqEBw51sw
# THyA1FBnoqXuDus9tfHleR7h9VgZb7uJbXjiIFgl/+RIs+av8bJABBdGUNQMbJEU
# fe7K4vYm3hs7BGdRLg+kF/dC/z+RiTH4p7yz5TpS3Cozf0pkkWXYZRG222q3tGxS
# /L+LcRbELM5zmqDpXQjBRUWlKYbsATFtXnTGVjELMIIHejCCBWKgAwIBAgIKYQ6Q
# 0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5
# WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQD
# Ex9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4
# BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe
# 0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato
# 88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v
# ++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDst
# rjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN
# 91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4ji
# JV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmh
# D+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbi
# wZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8Hh
# hUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaI
# jAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTl
# UAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNV
# HQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQF
# TuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29m
# dC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNf
# MjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5t
# aWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNf
# MjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcC
# ARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnlj
# cHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5
# AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oal
# mOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0ep
# o/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1
# HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtY
# SWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInW
# H8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZ
# iWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMd
# YzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7f
# QccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKf
# enoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOpp
# O6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZO
# SEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCFcswghXHAgEBMIGVMH4xCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jv
# c29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAADDDpun2LLc9ywAAAAAAMMw
# DQYJYIZIAWUDBAIBBQCggbowGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINn7p/pu
# 70KvbtjORWX6YdWr6MgoJbig+Wl7jegJlk3PME4GCisGAQQBgjcCAQwxQDA+oCCA
# HgBWAGEAbABpAGQAYQB0AGUAQQBPAFMALgBwAHMAMaEagBhodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEAK7yf7X6/4T4w2HSsh+yiFgwn
# VgX1NSp/xvpYTfNmBtM3YoIBMYV2HTLagdZrNRuU1UuVWMtGtXvMiKb64bBHrrvV
# oKCIT7/8q3fRzuW/F9NU8LWicp3O5s+xDxZpJEh2Z5GBWMve9DLI22HEpn5vsdVM
# uU+bMK3DoFXWRXSYSOl6Ndlfy05+AeRhphb5Un204MezKW2hTaNPxWQAGOyY4Mls
# uFPabdq4JRzF3jJIf9rUay4ztp0aMtkDBc2CzzHPc1o0ax4YqsuraPv1z/RJrzMG
# LZsvq+UEunLztmJNebHVWXv7hjSK2Df5iggw9SiUw5pm8dh60e2mRrDhy3CZOqGC
# E0kwghNFBgorBgEEAYI3AwMBMYITNTCCEzEGCSqGSIb3DQEHAqCCEyIwghMeAgED
# MQ8wDQYJYIZIAWUDBAIBBQAwggE8BgsqhkiG9w0BCRABBKCCASsEggEnMIIBIwIB
# AQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUABCAu9NCBj6IHHItBSTHkAOGE
# SdlGqp7VZxbHazaui/Yq7gIGWdQ0qb67GBMyMDE3MTAwNDEwNTgwMS44MDFaMAcC
# AQGAAgH0oIG4pIG1MIGyMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMQwwCgYDVQQLEwNBT0MxJzAlBgNVBAsTHm5DaXBoZXIgRFNFIEVTTjoxMkU3
# LTMwNjQtNjExMjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vydmlj
# ZaCCDs0wggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGI
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylN
# aWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3
# MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog
# 7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqV
# Hc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRg
# MlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcS
# chohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrK
# sajyeioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1e
# FpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYE
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBB
# MAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP
# 6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWlj
# cm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2
# LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMu
# Y3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcC
# ARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0
# Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBf
# AFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3i
# xuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5
# vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/G
# f/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9Z
# Kby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZ
# SnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCb
# IjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D
# 8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHL
# pwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp
# 9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8b
# xyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8N
# oFA12u8JJxzVs341Hgi62jbb01+P3nSISRIwggTZMIIDwaADAgECAhMzAAAArIoh
# vHrSm3L0AAAAAACsMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMB4XDTE2MDkwNzE3NTY1NFoXDTE4MDkwNzE3NTY1NFowgbIxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDDAKBgNVBAsTA0FPQzEn
# MCUGA1UECxMebkNpcGhlciBEU0UgRVNOOjEyRTctMzA2NC02MTEyMSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAocT0PKWOczGhF0Fcq3cIt6nRQ6q739x0+bo1VmqECdip
# u/tU9xjZxqWzQ+j6JgHMPTX1fgvkTJgq04aVJQVc3rs7DS9i7I/ZjHSvN4sXm2s3
# p0qwNK1yyIn1gcyh1T+o87EFqPenB7pB2aiPMUad7WIr4GqbeSy65/UZtiZ/hNId
# pSgzsObCLXmYq4jjDx9me5rYGF5sgfE4YHQeOqen6zRqXF69daWtVZJXZdImOqAQ
# CkEEsSeQZ+De7ouVo+cA5A2cxgIOp9abTD0zyYS9rqLFvOGI50qf9rLjWqd6joyh
# GF5qRs72rKuasqj8r36n5LDnzQWiZ7X6QvHSAySq5wIDAQABo4IBGzCCARcwHQYD
# VR0OBBYEFNhHcKiFNYsTYa+HkOhFFyTgmKcNMB8GA1UdIwQYMBaAFNVjOlyKMZDz
# Q3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9z
# b2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAx
# LmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0
# MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQEL
# BQADggEBAEjs6F4nwxsYnF20znZuNwwfXWMcDV2kI9IVtM7QQAnlm1+s8XntcO0y
# Xl0MdSH089QViQH1ZWuxwNaMWtC4hf1H+q30bxBJhph6/cFhG698YhK5ZUxRNlf5
# nWAUhMHY++JvECwXhWN+wo8eExXvgAfxUJct5L36ySg2mGE010wBWACqYtAHA03B
# El2XLISfzvFGbPX69AYKzpuYe6nkNQiTZgzFRKhJULf3BTt3caqwCr9xbv57E+Rp
# AAbvryIm4MV+rTZqnHCCFygC4L+8wyGkQAFrV1fS8J5rLQ1GyKfHR/6ElZt7T5wj
# 5awd/gtvLz57yXW7SYv8jrhE3fqy5/qhggN3MIICXwIBATCB4qGBuKSBtTCBsjEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEMMAoGA1UECxMDQU9D
# MScwJQYDVQQLEx5uQ2lwaGVyIERTRSBFU046MTJFNy0zMDY0LTYxMTIxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiJQoBATAJBgUrDgMCGgUA
# AxUAOXAlixTIed1fDF3pi5yzlJn3HLeggcEwgb6kgbswgbgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDDAKBgNVBAsTA0FPQzEnMCUGA1UECxMe
# bkNpcGhlciBOVFMgRVNOOjI2NjUtNEMzRi1DNURFMSswKQYDVQQDEyJNaWNyb3Nv
# ZnQgVGltZSBTb3VyY2UgTWFzdGVyIENsb2NrMA0GCSqGSIb3DQEBBQUAAgUA3X8p
# jzAiGA8yMDE3MTAwNDA5MzQwN1oYDzIwMTcxMDA1MDkzNDA3WjB3MD0GCisGAQQB
# hFkKBAExLzAtMAoCBQDdfymPAgEAMAoCAQACAhRKAgH/MAcCAQACAhi6MAoCBQDd
# gHsPAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwGgCjAIAgEAAgMW
# 42ChCjAIAgEAAgMHoSAwDQYJKoZIhvcNAQEFBQADggEBADrXG8Cx1p9x6sJZ2tfT
# Y/NSBGA70/Nb+c0VScPzv2kq/qwJTKdn954Ya94n6lYOlKNjmKFnzDaTnSRI4ng4
# +M0AVErXa8LKb2zPgJgKOpfS4Pq32yvDpQn7Cthf2gUNS8HNYSd5XmfXU2f1G1lb
# 337ZYcXA8VTP5/x9QReBTL3v9BL7eeSJpB3USIpUHUvE7eEmzZzmvQtcvICsTLO3
# xwduBJcv9gJx+LzQ8MMffl/8xDcO1oHNI8g5UA7dYeJJkyyYZcIJ2y22Z5EA77vK
# dxGqL78jMssUpkU7ynTQ9tXGr22E0vqkJe+Zd3OnuOvx7Fi1asOdpapFIv95IHwb
# E3IxggL1MIIC8QIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAIT
# MwAAAKyKIbx60pty9AAAAAAArDANBglghkgBZQMEAgEFAKCCATIwGgYJKoZIhvcN
# AQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCCYO9Y6dmz6RtrPLC6y
# J/m39PY0tleCSEtQK4Y/s/Jo1DCB4gYLKoZIhvcNAQkQAgwxgdIwgc8wgcwwgbEE
# FDlwJYsUyHndXwxd6Yucs5SZ9xy3MIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgUENBIDIwMTACEzMAAACsiiG8etKbcvQAAAAAAKwwFgQUwU++HvWuqWIbcG8H
# T6a56oLUXRowDQYJKoZIhvcNAQELBQAEggEASVgE+NfTGyYdoCLFnzarSBVfYErm
# SrFMWW3VLqGNFqhQM6x3mUuHYonB+kUHYahFNXjMU25+HoR6wsskdzyE9/fwAwZR
# /x/R+1YeSZulb3AHODr1CsQYextpWxSnBBQSZcTHi8OncCznP12EETEbG4318bFv
# QlBVZRndA6bwW81SRPDXI3nWhC57rceCokICBmGroOsjamWe7GHVmAWWa9eeBUU8
# 2zD9raWYmvvMAXrG+AuHAvPnkaRGQ25tvE+tRBfCXJWv9+zIH8qkLzXrzJFYTdZx
# 2FNKO9VcjCd1xgZpkQF1vAOdP8FT0eyI5zOrvle4omO/nPM9jqB7S+KKig==
# SIG # End signature block
